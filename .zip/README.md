# [murmur](http://songroger.github.io/murmur)

![preview](preview.png)

This is another simple theme for [jekyll](http://jekyllrb.com/).
Try to edit `_config.yml` first before use it.
Replace all the blabla configurations(like "avatar", "about", "title", etc.) to your owns.
